ComFi Telecom Icons

Copyright (C) 2010  Communications Fidelity, Boston, Massachusetts. All rights reserved. The icons are licensed under a Creative Commons Attribution 3.0 license. http://creativecommons.org/licenses/by/3.0/

If you can't or don't want to provide a link back, please
contact us. http://www.comfi.com/telecom-icons/

We are unavailable for custom icon design, but could make additional icons to the Telecom Icon set. Icon suggestions are always welcome to mailto:gasuns@comfi.com